// A TrackingService stand-in whose reported position is written by the test.
//
// The CV pipeline itself is covered in tests/cv, which drives the real
// TrackingService over synthesized frames. What this suite needs from a tracker
// is the ability to put a champion at an exact game coordinate, which no
// pixel-level harness can do without also proving the detector — and would then
// be testing two things at once.
//
// Three getters here gate the entire network path in positionTickInner: a
// SCANNING state short-circuits to a local ally-only 1.0, a (0,0) position
// returns early, and a hold above 2s stops reporting. A fake that defaulted to
// any of those would never reach the server, and every downstream failure would
// read as "wrong volume" rather than "no request was ever sent".

import { TrackingState } from '../../../src/services/tracking';
import { HoldReason } from '../../../src/services/tracking-helpers';
import { Position } from '../../../src/core/types';
import { ScreenRect } from '../../../src/core/map-calibration';

// Successive trackers start on different corners of the map, every pair of them
// further apart than the 1350-unit cross-team hearing range. A shared start
// coordinate put two champions on the same pixel until the first scripted move
// propagated, and a zero-distance exchange answers "ally at 1.0" and "enemy in
// range" on the ordinary distance rule alone — so assertions about the rules
// that are supposed to produce those answers held whether or not the rules
// existed. Consecutive entries are always distinct, which is what the two
// clients of a test need; the list is round-robined so a long run stays inside
// the map.
const START_POSITIONS: readonly Position[] = [
  { x: 1500, y: 1500 },
  { x: 13000, y: 13000 },
  { x: 1500, y: 13000 },
  { x: 13000, y: 1500 },
];
let startSeq = 0;

export class ScriptedTracker {
  state: TrackingState = TrackingState.LOCKED;
  position: Position | null = { ...START_POSITIONS[startSeq++ % START_POSITIONS.length] };
  cameraPosition: Position | null = null;
  holdSec = 0;
  /** Why the scripted hold is happening; drives how fast the orchestrator
   *  disowns our coordinates (see disownAfterSec). Left at the cautious
   *  'no-match' so a test that only sets holdSec keeps the old behaviour. */
  holdReason: Exclude<HoldReason, null> = 'no-match';
  cameraTrackingEnabled = false;
  started = false;
  stopped = false;
  deaths = 0;
  respawns = 0;
  classifierSet = false;
  classifier: unknown = null;
  appliedMinimapScale: number | null = null;

  private onPositionUpdate: ((pos: Position) => void) | null = null;
  private fps = 30;

  constructor(readonly gameRect: ScreenRect) {}

  readonly captureBounds = { x: 0, y: 0, width: 376, height: 376 };

  loadChampionTemplate(_championName: string): void { /* colour filter, nothing to load */ }
  async initCaptureBounds(): Promise<void> { /* no backend to tell */ }
  setClassifier(c: unknown): void { this.classifierSet = true; this.classifier = c; }
  /** Camera mode's reader, as the orchestrator hands it over (or null). */
  cameraHearing: unknown = null;
  setCameraHearing(h: unknown): void { this.cameraHearing = h; }
  setMinimapScaleFromConfig(scale: number): void { this.appliedMinimapScale = scale; }
  setMinimapRegion(_r: unknown): void { /* calibration is not exercised here */ }

  start(onPositionUpdate: (pos: Position) => void, fps = 30): void {
    this.started = true;
    this.stopped = false;
    this.onPositionUpdate = onPositionUpdate;
    this.fps = fps;
  }
  stop(): void { this.stopped = true; this.onPositionUpdate = null; }

  getState(): TrackingState { return this.state; }
  getLastPosition(): Position | null { return this.position; }
  getHoldDurationSec(): number { return this.holdSec; }
  getHoldReason(): HoldReason { return this.holdSec > 0 ? this.holdReason : null; }
  /** Where the script says we were last seen; null (the default) when lost
   *  means no anchor, so the orchestrator falls back to team-only. */
  lastSeen: Position | null = null;
  getLastSeenPosition(_maxAgeMs: number): Position | null { return this.lastSeen; }
  getLastSeenAgeMs(): number { return 0; }
  getCameraPosition(): Position | null {
    return this.cameraTrackingEnabled ? this.cameraPosition : null;
  }
  getCameraView(): { x: number; y: number; w: number; h: number } | null {
    if (!this.cameraTrackingEnabled || !this.cameraPosition || !this.cameraSize) return null;
    return { ...this.cameraPosition, ...this.cameraSize };
  }
  /** Size of the scripted camera box, or null for a centre-only camera. */
  cameraSize: { w: number; h: number } | null = null;
  /**
   * Enemy icons the scripted minimap is drawing. Unscripted (undefined), the
   * client reports none at all, as an older client would, and the server
   * scores it without the fog-of-war check — which is what every test written
   * before that check assumes.
   */
  visibleEnemies: Array<{ x: number; y: number; n: number }> | undefined = undefined;
  getVisibleEnemies(): Array<{ x: number; y: number; n: number }> | undefined {
    return this.visibleEnemies?.map(p => ({ ...p }));
  }
  setCameraTracking(enabled: boolean): void {
    this.cameraTrackingEnabled = enabled;
    if (!enabled) this.cameraPosition = null;
  }
  /** A scripted camera position is either set or absent; when it is absent the
   *  reason is that the script said so, which is not one of the real detector's
   *  failure modes. */
  getCameraMiss(): null { return null; }
  getFilteredImageUrl(): string | null { return null; }
  getDetectedMinimapScreenBounds(): null { return null; }
  getScanFps(): number { return this.fps; }
  getGameRect(): ScreenRect { return this.gameRect; }
  /** Mirrors the real onDeath: a LOCKED tracker keeps the body where it is and
   *  clears any hold; any other state has no body to keep. */
  onDeath(): void {
    this.deaths++;
    if (this.state !== TrackingState.LOCKED) this.position = null;
    this.state = TrackingState.DEAD;
    this.holdSec = 0;
  }
  onRespawn(): void { this.respawns++; this.state = TrackingState.SCANNING; }
  resets = 0;
  /** Mirrors the real resetPosition: ignored while dead, otherwise rescans. */
  resetPosition(): boolean {
    if (this.state === TrackingState.DEAD) return false;
    this.resets++;
    this.state = TrackingState.SCANNING;
    this.holdSec = 0;
    return true;
  }
  rescans = 0;
  /** Mirrors the real rescan (shared RESET): only from a clean lock. */
  rescan(): boolean {
    if (this.state !== TrackingState.LOCKED || this.holdSec > 0) return false;
    this.rescans++;
    this.state = TrackingState.SCANNING;
    this.holdSec = 0;
    return true;
  }

  /** Walk the champion to a new game coordinate. */
  moveTo(x: number, y: number): void {
    this.position = { x, y };
    this.onPositionUpdate?.(this.position);
  }

  /** Point the in-game camera somewhere, for the voice-on-camera path (#36). */
  lookAt(x: number, y: number, size?: { w: number; h: number }): void {
    this.cameraPosition = { x, y };
    this.cameraSize = size ?? null;
  }

  /** Put enemy icons on the scripted minimap (what the player can see). */
  sees(...points: Position[]): void {
    this.visibleEnemies = points.map(p => ({ x: p.x, y: p.y, n: 1 }));
  }
}
