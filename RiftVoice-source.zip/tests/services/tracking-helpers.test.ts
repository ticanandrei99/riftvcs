import {
  computeMaxJumpPx,
  computeReacquireThreshold,
  computeBlobScore,
  pickBestBlobInRange,
  pickClassifierReacquisition,
  CLS_FOLLOW_THRESHOLD,
  shouldForceReacquisition,
  FORCED_REACQUIRE_HOLD_MS,
  nextClassifierEma,
  computeNearFieldPx,
  computeViewportCenter,
  describeViewportCenter,
  emptyWrongLockEvidence,
  nextWrongLockEvidence,
  WrongLockEvidence,
  WrongLockRun,
  WRONG_LOCK_RUNS,
  WRONG_LOCK_MIN_MS,
  WRONG_LOCK_STALE_MS,
  reacquireThresholdAt,
  reacquireReachUnits,
  isInBaseZone,
  FAR_REACQUIRE_THRESHOLD,
  REACQUIRE_REACH_BASE_UNITS,
  REACQUIRE_REACH_UNITS_PER_SEC,
  CameraDwell,
  cameraFavourite,
  cameraSwitchTarget,
  readingNear,
  CAMERA_DWELL_WINDOW_MS,
  CAMERA_DWELL_MIN_READABLE_MS,
  CAMERA_DWELL_LOW,
  CAMERA_DWELL_MIN_READABLE_SHARE,
  TeammateVerdicts,
  discShare,
  filledIconRing,
  outlineRoundness,
} from '../../src/services/tracking-helpers';
import type { Blob } from '../../src/services/blob-types';

function mkBlob(cx: number, cy: number): Blob {
  return {
    color: 'teal',
    pixels: 100,
    cx, cy,
    minX: cx - 5, maxX: cx + 5,
    minY: cy - 5, maxY: cy + 5,
    fillRatio: 0.8,
  };
}

describe('computeMaxJumpPx', () => {
  test('returns 2x icon-diameter base when not in hold', () => {
    expect(computeMaxJumpPx(12, /*holdStartMs*/ 0, /*now*/ 1000)).toBe(24);
  });

  test('enforces minimum of 20 even for tiny icons', () => {
    expect(computeMaxJumpPx(5, 0, 1000)).toBe(20);
  });

  test('expands by ~1 icon-diameter per second of hold', () => {
    // hold for 2 seconds, icon = 12 → base 24 + (12 * 2) = 48
    expect(computeMaxJumpPx(12, /*hold start*/ 1000, /*now*/ 3000)).toBe(48);
  });

  test('zero hold equals no expansion', () => {
    expect(computeMaxJumpPx(12, 1000, 1000)).toBe(24);
  });
});

describe('computeReacquireThreshold', () => {
  test('default 0.5 when fresh + brief hold', () => {
    expect(computeReacquireThreshold(/*stationary*/ 0, /*hold*/ 0)).toBe(0.5);
  });

  test('relaxes to 0.35 after >1s of hold', () => {
    expect(computeReacquireThreshold(0, 2)).toBe(0.35);
  });

  test('tightens to 0.85 if stationary for >3s (likely render glitch, not teleport)', () => {
    expect(computeReacquireThreshold(5, 0)).toBe(0.85);
    // Stationary check wins even if hold has been short
    expect(computeReacquireThreshold(5, 2)).toBe(0.85);
  });
});

describe('computeBlobScore', () => {
  test('with classifier: an all-1 candidate scores exactly 1 (weights are normalized)', () => {
    const s = computeBlobScore({ posScore: 1, clsScore: 1, whiteScore: 1 }, true);
    expect(s).toBeCloseTo(1.0, 12);
  });

  test('without classifier: an all-1 candidate scores exactly 1', () => {
    const s = computeBlobScore({ posScore: 1, clsScore: 1, whiteScore: 1 }, false);
    expect(s).toBeCloseTo(1.0, 12);
  });

  test('without classifier: clsScore is ignored entirely', () => {
    // cls=0 (modified) and cls=1 should both produce the same score when no classifier
    const a = computeBlobScore({ posScore: 0.5, clsScore: 0, whiteScore: 0.5 }, false);
    const b = computeBlobScore({ posScore: 0.5, clsScore: 1, whiteScore: 0.5 }, false);
    expect(a).toBe(b);
  });

  test('higher posScore strictly wins (ceteris paribus)', () => {
    const lo = computeBlobScore({ posScore: 0.2, clsScore: 0.5, whiteScore: 0.5 }, true);
    const hi = computeBlobScore({ posScore: 0.8, clsScore: 0.5, whiteScore: 0.5 }, true);
    expect(hi).toBeGreaterThan(lo);
  });

  // Single-term probes pin each renormalized weight to a literal value. A
  // ranking-equivalence test cannot do this: dividing every surviving term by
  // ANY single constant preserves ordering, so only the absolute values catch
  // a wrong (or missing) divisor after the dead peer term was dropped.
  describe('renormalized weights (peer term removed)', () => {
    test('with classifier: pos 0.35/0.85, cls 0.30/0.85, white 0.20/0.85', () => {
      expect(computeBlobScore({ posScore: 1, clsScore: 0, whiteScore: 0 }, true))
        .toBeCloseTo(0.4117647, 6);
      expect(computeBlobScore({ posScore: 0, clsScore: 1, whiteScore: 0 }, true))
        .toBeCloseTo(0.3529412, 6);
      expect(computeBlobScore({ posScore: 0, clsScore: 0, whiteScore: 1 }, true))
        .toBeCloseTo(0.2352941, 6);
    });

    test('without classifier: pos 0.45/0.70, white 0.25/0.70', () => {
      expect(computeBlobScore({ posScore: 1, clsScore: 0, whiteScore: 0 }, false))
        .toBeCloseTo(0.6428571, 6);
      expect(computeBlobScore({ posScore: 0, clsScore: 0, whiteScore: 1 }, false))
        .toBeCloseTo(0.3571429, 6);
    });

    test('the surviving terms keep their pre-removal ratios exactly', () => {
      // pos:cls:white was 0.35:0.30:0.20 with the classifier and 0.45:-:0.25
      // without it. Renormalizing must not re-rank anything, so the ratios —
      // not just the ordering — have to survive.
      const pos = computeBlobScore({ posScore: 1, clsScore: 0, whiteScore: 0 }, true);
      const cls = computeBlobScore({ posScore: 0, clsScore: 1, whiteScore: 0 }, true);
      const white = computeBlobScore({ posScore: 0, clsScore: 0, whiteScore: 1 }, true);
      expect(pos / cls).toBeCloseTo(0.35 / 0.30, 10);
      expect(cls / white).toBeCloseTo(0.30 / 0.20, 10);

      const posNo = computeBlobScore({ posScore: 1, clsScore: 0, whiteScore: 0 }, false);
      const whiteNo = computeBlobScore({ posScore: 0, clsScore: 0, whiteScore: 1 }, false);
      expect(posNo / whiteNo).toBeCloseTo(0.45 / 0.25, 10);
    });
  });
});

describe('pickBestBlobInRange', () => {
  const noScores = {
    cls: () => 0.5,
    white: () => 0.5,
  };

  test('picks the blob closest to the predicted position', () => {
    const blobs = [mkBlob(100, 100), mkBlob(105, 100), mkBlob(150, 100)];
    const result = pickBestBlobInRange(
      blobs,
      /*lastReg*/ { x: 95, y: 100 },
      /*predicted*/ { x: 105, y: 100 },
      /*maxJumpPx*/ 60,
      /*hasClassifier*/ false,
      noScores,
    );
    expect(result?.blob.cx).toBe(105);
  });

  test('excludes blobs outside jump radius', () => {
    const blobs = [mkBlob(200, 100)]; // 100px away from lastReg
    const result = pickBestBlobInRange(
      blobs,
      { x: 100, y: 100 },
      { x: 100, y: 100 },
      30,
      false,
      noScores,
    );
    expect(result).toBeNull();
  });

  test('with classifier, drops FAR-FIELD blobs below CLS_FOLLOW_THRESHOLD', () => {
    // 25px from the prediction with a 12px near-field radius — the classifier
    // still has to vouch for it, which is what stops long holds from snapping
    // the dot onto a minion wave (#13).
    const blob = mkBlob(125, 100);
    const lowClsFns = { ...noScores, cls: () => CLS_FOLLOW_THRESHOLD - 0.01 };
    const result = pickBestBlobInRange(
      [blob],
      { x: 100, y: 100 },
      { x: 100, y: 100 },
      30,
      true,
      lowClsFns,
      /*nearFieldPx*/ 12,
    );
    expect(result).toBeNull();
  });

  test('with classifier, follows a NEAR-FIELD blob the classifier scores at zero', () => {
    const blob = mkBlob(102, 100);
    const zeroClsFns = { ...noScores, cls: () => 0 };
    const result = pickBestBlobInRange(
      [blob],
      { x: 100, y: 100 },
      { x: 100, y: 100 },
      30,
      true,
      zeroClsFns,
      /*nearFieldPx*/ 12,
    );
    expect(result?.blob).toBe(blob);
  });

  test('near field is measured from lastReg too, so a stale velocity EMA cannot veto', () => {
    // Champion standing still; velocity EMA still points 20px away, so the
    // prediction is off but the blob has not moved from lastReg.
    const blob = mkBlob(100, 100);
    const zeroClsFns = { ...noScores, cls: () => 0 };
    const result = pickBestBlobInRange(
      [blob],
      /*lastReg*/ { x: 100, y: 100 },
      /*predicted*/ { x: 120, y: 100 },
      /*maxJumpPx*/ 60,
      true,
      zeroClsFns,
      /*nearFieldPx*/ 12,
    );
    expect(result?.blob).toBe(blob);
  });

  // Regression for the lock → hold → forced-reacquire → lock cycle in
  // NotOtakuu's 2026-09-12 log (v0.5.7). Real values from that session:
  // single teal blob at region (28,308), iconDiam 30, classifier raw=0.000 /
  // ema=0.00 on every frame, velocity reset to 0 by the lock one tick earlier.
  // Before the near-field exemption, Phase 1 rejected the blob it had just
  // locked onto and the broadcast position froze at the fountain — which is
  // what made every enemy fall outside MAX_HEARING_RANGE.
  test('regression: follows the just-locked blob when the classifier scores it 0', () => {
    const blob = mkBlob(28, 308);
    const lastReg = { x: 28, y: 308 };
    const predicted = { x: 28, y: 308 };
    const maxJumpPx = computeMaxJumpPx(30, /*holdStartMs*/ 0, /*now*/ 1000);
    const deadClassifier = { cls: () => 0.0, white: () => 0.8 };

    const phase1 = pickBestBlobInRange(
      [blob], lastReg, predicted, maxJumpPx, /*hasClassifier*/ true, deadClassifier,
      computeNearFieldPx(30),
    );

    expect(phase1).not.toBeNull();
    expect(phase1?.blob.cx).toBe(28);
  });

  test('without classifier, low cls scores do not exclude blobs', () => {
    const blob = mkBlob(100, 100);
    const lowClsFns = { ...noScores, cls: () => 0.0 };
    const result = pickBestBlobInRange(
      [blob],
      { x: 100, y: 100 },
      { x: 100, y: 100 },
      30,
      false,
      lowClsFns,
    );
    expect(result?.blob).toBe(blob);
  });

  test('empty input returns null', () => {
    expect(pickBestBlobInRange([], { x: 0, y: 0 }, { x: 0, y: 0 }, 30, false, noScores)).toBeNull();
  });
});

describe('pickClassifierReacquisition', () => {
  test('returns highest-confidence blob above threshold', () => {
    const blobs = [mkBlob(0, 0), mkBlob(50, 50), mkBlob(200, 200)];
    const scores = new Map<Blob, number>([
      [blobs[0], 0.4],   // below threshold (0.5)
      [blobs[1], 0.7],
      [blobs[2], 0.9],
    ]);
    const result = pickClassifierReacquisition(blobs, 0.5, (b) => scores.get(b) ?? 0);
    expect(result?.blob).toBe(blobs[2]);
    expect(result?.score).toBe(0.9);
  });

  test('returns null when no blob clears the threshold', () => {
    const blobs = [mkBlob(0, 0), mkBlob(50, 50)];
    const result = pickClassifierReacquisition(blobs, 0.8, () => 0.5);
    expect(result).toBeNull();
  });

  test('threshold of 0 returns highest-scoring blob (no exclusion)', () => {
    const blobs = [mkBlob(0, 0), mkBlob(50, 50)];
    const scores = new Map<Blob, number>([[blobs[0], 0.1], [blobs[1], 0.3]]);
    const result = pickClassifierReacquisition(blobs, 0, (b) => scores.get(b) ?? 0);
    expect(result?.blob).toBe(blobs[1]);
  });

  test('empty input returns null', () => {
    expect(pickClassifierReacquisition([], 0.5, () => 1.0)).toBeNull();
  });
});

// ---------- v0.3 tracking tweaks (issue #7 root-cause fixes) ----------

describe('shouldForceReacquisition', () => {
  test('returns false when no hold is active (holdStartMs === 0)', () => {
    expect(shouldForceReacquisition(0, 1_000_000)).toBe(false);
  });
  test('returns false for hold below the threshold', () => {
    expect(shouldForceReacquisition(1000, 1000 + FORCED_REACQUIRE_HOLD_MS - 1)).toBe(false);
  });
  test('returns true at exactly the threshold', () => {
    expect(shouldForceReacquisition(1000, 1000 + FORCED_REACQUIRE_HOLD_MS)).toBe(true);
  });
  test('returns true for hold far past threshold (44-second IXAM-log case)', () => {
    expect(shouldForceReacquisition(1000, 1000 + 44_000)).toBe(true);
  });
});

describe('nextClassifierEma (symmetric EMA — v0.3.0 snap-up reverted in v0.3.1)', () => {
  test('decays toward 0 on a 0 sample', () => {
    // 0.5 * 0.7 + 0 * 0.3 = 0.35
    expect(nextClassifierEma(0.5, 0, 0.7)).toBeCloseTo(0.35, 5);
  });
  test('rises gradually toward a higher raw — does NOT snap (anti-clinging)', () => {
    // A single false-high raw must not latch the EMA to 1.0 (the v0.3.0
    // snap-up bug that made the tracker cling to minions/structures).
    // 0 * 0.7 + 0.8 * 0.3 = 0.24, not 0.8.
    expect(nextClassifierEma(0, 0.8, 0.7)).toBeCloseTo(0.24, 5);
  });
  test('standard EMA when raw is below current', () => {
    // 0.6 * 0.7 + 0.4 * 0.3 = 0.42 + 0.12 = 0.54
    expect(nextClassifierEma(0.6, 0.4, 0.7)).toBeCloseTo(0.54, 5);
  });
  test('a sustained high raw still climbs over a few frames', () => {
    let ema = 0;
    for (let i = 0; i < 5; i++) ema = nextClassifierEma(ema, 0.9, 0.7);
    expect(ema).toBeGreaterThan(0.6); // recovers without single-frame latching
  });
});

describe('computeViewportCenter (#36 voice on camera)', () => {
  const W = 340, H = 340;

  /** Draw a rectangle OUTLINE into a fresh mask, the way the minimap shows it. */
  function mkMask(
    left: number, top: number, right: number, bottom: number,
    w = W, h = H,
  ): Uint8Array {
    const mask = new Uint8Array(w * h);
    for (let x = left; x <= right; x++) {
      mask[top * w + x] = 1;
      mask[bottom * w + x] = 1;
    }
    for (let y = top; y <= bottom; y++) {
      mask[y * w + left] = 1;
      mask[y * w + right] = 1;
    }
    return mask;
  }

  test('finds the centre of a plausible camera rectangle', () => {
    // ~66x37px box, the rough shape of a 1920x1080 camera on a 340px minimap.
    const c = computeViewportCenter(mkMask(100, 150, 166, 187), W, H);
    expect(c).toEqual({ cx: 133, cy: 168.5 });
  });

  test('a stray long run elsewhere does not drag the centre off the box', () => {
    // A rectangle plus an unrelated 20px horizontal streak in the far corner.
    // A raw bounding box would put the centre between the two; using rows and
    // columns that carry a full edge's worth of pixels ignores the streak.
    const mask = mkMask(100, 150, 166, 187);
    for (let x = 300; x < 320; x++) mask[330 * W + x] = 1;
    const c = computeViewportCenter(mask, W, H);
    expect(c).toEqual({ cx: 133, cy: 168.5 });
  });

  test('rejects a box spanning most of the minimap (mask noise, not a camera)', () => {
    expect(computeViewportCenter(mkMask(5, 5, 334, 334), W, H)).toBeNull();
  });

  test('rejects a box too small to be the camera', () => {
    expect(computeViewportCenter(mkMask(100, 100, 108, 108), W, H)).toBeNull();
  });

  test('returns null for an empty mask (no rectangle visible)', () => {
    expect(computeViewportCenter(new Uint8Array(W * H), W, H)).toBeNull();
  });

  test('returns null when only one vertical edge is on screen', () => {
    // Camera panned into the map edge — the box is clipped, so a centre would
    // be off by half its width. Caller falls back to the champion position.
    const mask = new Uint8Array(W * H);
    for (let y = 150; y <= 187; y++) mask[y * W + 100] = 1;
    for (let x = 100; x <= 166; x++) { mask[150 * W + x] = 1; mask[187 * W + x] = 1; }
    expect(computeViewportCenter(mask, W, H)).toBeNull();
  });

  test('handles a 2px-thick (anti-aliased) rectangle outline', () => {
    const mask = mkMask(100, 150, 166, 187);
    // Second pixel of each edge, the way an anti-aliased box renders.
    for (let x = 100; x <= 166; x++) { mask[151 * W + x] = 1; mask[186 * W + x] = 1; }
    for (let y = 150; y <= 187; y++) { mask[y * W + 101] = 1; mask[y * W + 165] = 1; }
    const c = computeViewportCenter(mask, W, H);
    // The centre lands within a pixel of the true one — well under the ~44
    // game units a single minimap pixel is worth at this scale.
    expect(c).not.toBeNull();
    expect(Math.abs(c!.cx - 133)).toBeLessThanOrEqual(1);
    expect(Math.abs(c!.cy - 168.5)).toBeLessThanOrEqual(1);
  });

  test('guards against a mask smaller than the stated region', () => {
    expect(computeViewportCenter(new Uint8Array(10), W, H)).toBeNull();
    expect(computeViewportCenter(new Uint8Array(0), 0, 0)).toBeNull();
  });
});

describe('describeViewportCenter — why a camera frame missed', () => {
  const W = 340, H = 340;

  function mkMask(left: number, top: number, right: number, bottom: number): Uint8Array {
    const mask = new Uint8Array(W * H);
    for (let x = left; x <= right; x++) { mask[top * W + x] = 1; mask[bottom * W + x] = 1; }
    for (let y = top; y <= bottom; y++) { mask[y * W + left] = 1; mask[y * W + right] = 1; }
    return mask;
  }

  // These four reasons need opposite fixes — a threshold that is too strict
  // versus a rectangle that is the wrong shape — so a bug report has to be able
  // to tell them apart. Before this, every one of them logged "not readable".
  test('an empty mask reports no-marked-pixels, not a shape failure', () => {
    const r = describeViewportCenter(new Uint8Array(W * H), W, H);
    expect(r.centre).toBeNull();
    expect(r.miss).toBe('no-marked-pixels');
    expect(r.markedPixels).toBe(0);
  });

  test('marked pixels that form no rectangle report no-opposing-edges', () => {
    // A single long horizontal streak: pixels exist, but there is no second
    // edge to pair it with.
    const mask = new Uint8Array(W * H);
    for (let x = 100; x < 180; x++) mask[150 * W + x] = 1;
    const r = describeViewportCenter(mask, W, H);
    expect(r.centre).toBeNull();
    expect(r.miss).toBe('no-opposing-edges');
    expect(r.markedPixels).toBeGreaterThan(0);
  });

  test('a box spanning most of the minimap reports span-too-large', () => {
    const r = describeViewportCenter(mkMask(5, 5, 334, 334), W, H);
    expect(r.centre).toBeNull();
    expect(r.miss).toBe('span-too-large');
  });

  test('a real camera box reports a centre and no miss', () => {
    const r = describeViewportCenter(mkMask(100, 150, 166, 187), W, H);
    expect(r.centre).toEqual({ cx: 133, cy: 168.5 });
    expect(r.miss).toBeUndefined();
    expect(r.markedPixels).toBeGreaterThan(0);
  });

  test('computeViewportCenter still returns just the centre', () => {
    expect(computeViewportCenter(mkMask(100, 150, 166, 187), W, H)).toEqual({ cx: 133, cy: 168.5 });
    expect(computeViewportCenter(new Uint8Array(W * H), W, H)).toBeNull();
  });
});

describe('nextWrongLockEvidence', () => {
  const ICON = 30;
  const WARD = { x: 130, y: 133 };
  const REAL = { x: 218, y: 204, score: 1 };
  const against: WrongLockRun = { followed: WARD, followedScore: 0, best: REAL, discriminating: true };

  function feed(runs: WrongLockRun[], startMs = 1000, stepMs = 500) {
    let ev: WrongLockEvidence = emptyWrongLockEvidence();
    let switchTo: { x: number; y: number } | null = null;
    let at = -1;
    runs.forEach((r, i) => {
      const out = nextWrongLockEvidence(ev, r, startMs + i * stepMs, ICON);
      ev = out.evidence;
      if (out.switchTo && !switchTo) { switchTo = out.switchTo; at = i; }
    });
    return { ev, switchTo: switchTo as { x: number; y: number } | null, at };
  }

  test('switches once enough contrary runs span enough time', () => {
    const { switchTo, at } = feed(Array(12).fill(against));
    expect(switchTo).toEqual({ x: REAL.x, y: REAL.y });
    // Six runs would be 2.5s at 500ms; the time floor is what decides.
    expect(at).toBe(WRONG_LOCK_MIN_MS / 500);
    expect(at + 1).toBeGreaterThanOrEqual(WRONG_LOCK_RUNS);
  });

  test('needs the run count even when the time has passed', () => {
    const { switchTo, at } = feed(Array(8).fill(against), 1000, 2000);
    expect(switchTo).not.toBeNull();
    expect(at + 1).toBe(WRONG_LOCK_RUNS);
  });

  test('silent runs neither count nor reset', () => {
    const silent: WrongLockRun = { ...against, discriminating: false };
    const runs = [against, silent, against, silent, against, silent, against, silent, against, silent, against];
    expect(feed(runs).switchTo).not.toBeNull();
    expect(feed(runs.slice(0, 10)).switchTo).toBeNull();
  });

  test('one run that vouches for the followed blob resets everything', () => {
    const runs = [...Array(7).fill(against), { ...against, followedScore: 0.6 }, ...Array(5).fill(against)];
    expect(feed(runs).switchTo).toBeNull();
  });

  test('a followed blob that moves resets the evidence', () => {
    // 2px per 500ms run: slower than any champion walks.
    const walking = Array.from({ length: 12 }, (_, i) => ({ ...against, followed: { x: WARD.x + i * 2, y: WARD.y } }));
    expect(feed(walking).switchTo).toBeNull();
  });

  test('the preferred blob must be a different icon, and a clear favourite', () => {
    expect(feed(Array(12).fill({ ...against, best: { x: WARD.x + 10, y: WARD.y, score: 1 } })).switchTo).toBeNull();
    expect(feed(Array(12).fill({ ...against, best: { ...REAL, score: 0.9 } })).switchTo).toBeNull();
    expect(feed(Array(12).fill({ ...against, followedScore: 0.3 })).switchTo).toBeNull();
    expect(feed(Array(12).fill({ ...against, followed: null })).switchTo).toBeNull();
  });

  test('noise spread across several allies never adds up', () => {
    const allies = [{ x: 30, y: 120 }, { x: 250, y: 60 }, { x: 200, y: 260 }];
    const runs = Array.from({ length: 20 }, (_, i) => ({ ...against, best: { ...allies[i % 3], score: 1 } }));
    expect(feed(runs).switchTo).toBeNull();
  });

  test('a stray hit every 12s never adds up, however long it goes on', () => {
    const silent: WrongLockRun = { ...against, discriminating: false };
    const runs = Array.from({ length: 24 * 15 }, (_, i) => (i % 24 === 0 ? against : silent));
    expect(feed(runs).switchTo).toBeNull();
  });

  test('a discriminating run that does not support the switch resets it', () => {
    const weak: WrongLockRun = { ...against, followedScore: 0.3 };
    const runs = [...Array(5).fill(against), weak, ...Array(5).fill(against)];
    expect(feed(runs).switchTo).toBeNull();
  });

  test('a preferred icon that walks is still the same icon', () => {
    const runs = Array.from({ length: 12 }, (_, i) => ({ ...against, best: { x: REAL.x + i * 3, y: REAL.y, score: 1 } }));
    expect(feed(runs).switchTo).toEqual({ x: REAL.x + 8 * 3, y: REAL.y });
  });

  test('evidence goes stale', () => {
    let ev = emptyWrongLockEvidence();
    for (let i = 0; i < 5; i++) ev = nextWrongLockEvidence(ev, against, 1000 + i * 500, ICON).evidence;
    expect(ev.runs).toBe(5);
    const later = nextWrongLockEvidence(ev, against, 3000 + WRONG_LOCK_STALE_MS + 1, ICON);
    expect(WRONG_LOCK_STALE_MS).toBeLessThanOrEqual(3000);
    expect(later.switchTo).toBeNull();
    expect(later.evidence.runs).toBe(1);
  });
});

describe('reacquireThresholdAt — how far a re-acquisition may move us', () => {
  const SR = { width: 14870, height: 14980 };
  const TOP = { x: 1912, y: 11850 };

  test('nearby keeps the ordinary threshold', () => {
    expect(reacquireThresholdAt(0.35, { x: 3000, y: 12500 }, TOP, 0.6, SR)).toBe(0.35);
  });

  test('top lane to bot lane in 0.6 s needs the far threshold (the gcg545 log)', () => {
    expect(reacquireThresholdAt(0.5, { x: 11541, y: 2459 }, TOP, 0.64, SR)).toBe(FAR_REACQUIRE_THRESHOLD);
  });

  test('reach grows with time since we were last seen', () => {
    const far = { x: 6000, y: 8000 };
    const dist = Math.hypot(far.x - TOP.x, far.y - TOP.y);
    expect(reacquireReachUnits(0)).toBeLessThan(dist);
    expect(reacquireThresholdAt(0.35, far, TOP, 0, SR)).toBe(FAR_REACQUIRE_THRESHOLD);
    const sec = (dist - REACQUIRE_REACH_BASE_UNITS) / REACQUIRE_REACH_UNITS_PER_SEC + 0.1;
    expect(reacquireThresholdAt(0.35, far, TOP, sec, SR)).toBe(0.35);
  });

  test('a recall to either fountain is exempt', () => {
    expect(isInBaseZone({ x: 500, y: 500 }, SR)).toBe(true);
    expect(isInBaseZone({ x: 14300, y: 14400 }, SR)).toBe(true);
    expect(isInBaseZone({ x: 13600, y: 1500 }, SR)).toBe(false);
    expect(reacquireThresholdAt(0.5, { x: 14300, y: 14400 }, { x: 1000, y: 2000 }, 0.1, SR)).toBe(0.5);
  });

  test('never lowers an already higher ordinary threshold, and needs a last sighting', () => {
    expect(reacquireThresholdAt(0.95, { x: 11541, y: 2459 }, TOP, 0.5, SR)).toBe(0.95);
    expect(reacquireThresholdAt(0.35, { x: 11541, y: 2459 }, null, 0.5, SR)).toBe(0.35);
  });

  test('pickClassifierReacquisition takes a per-blob threshold', () => {
    const near = mkBlob(10, 10);
    const far = mkBlob(200, 200);
    const picked = pickClassifierReacquisition([near, far], (b) => (b === far ? 0.9 : 0.5),
      (b) => (b === far ? 0.85 : 0.6));
    expect(picked?.blob).toBe(near);
  });
});

describe('CameraDwell', () => {
  const DIAM = 24;
  const BOX = { x0: 100, y0: 100, x1: 200, y1: 180 };

  /** `seconds` of 8 FPS frames; `icons` and `box` may vary with the time. */
  function feed(d: CameraDwell, from: number, seconds: number,
    icons: (t: number) => Array<{ x: number; y: number }>, box: (t: number) => typeof BOX | null): number {
    let now = from;
    for (let i = 0; i < seconds * 8; i++) {
      now += 125;
      d.update(icons(now), box(now), now, 125, DIAM);
    }
    return now;
  }

  test('is the share of readable time each icon spent inside the rectangle', () => {
    const d = new CameraDwell();
    // A in view throughout, B never; the rectangle unreadable a quarter of the time.
    let k = 0;
    feed(d, 0, 20, () => [{ x: 150, y: 140 }, { x: 20, y: 20 }], () => (k++ % 4 === 0 ? null : BOX));
    const [a, b] = d.readings();
    expect(a.dwell).toBe(1);
    expect(b.dwell).toBe(0);
    // Unreadable frames count for neither icon.
    expect(a.readableMs).toBeCloseTo(15_000, -3);
  });

  test('follows an icon as it walks, and forgets what is older than the window', () => {
    const d = new CameraDwell();
    // In view for the first 20s, then out of view for 30s, walking all along.
    const end = feed(d, 0, 50, (t) => [{ x: 150 + t / 2000, y: 140 }],
      (t) => (t < 20_000 ? BOX : { x0: 0, y0: 0, x1: 60, y1: 60 }));
    const [a] = d.readings();
    expect(d.readings()).toHaveLength(1);
    expect(a.x).toBeCloseTo(150 + end / 2000, 0);
    expect(a.dwell).toBe(0);
    expect(a.readableMs).toBeLessThanOrEqual(CAMERA_DWELL_WINDOW_MS);
  });

  test('counts the time an icon was seen with the rectangle unreadable, apart', () => {
    const d = new CameraDwell();
    let k = 0;
    feed(d, 0, 20, () => [{ x: 150, y: 140 }], () => (k++ % 2 === 0 ? null : BOX));
    const [a] = d.readings();
    expect(a.seenMs).toBeCloseTo(20_000, -3);
    expect(a.readableMs).toBeCloseTo(10_000, -3);
  });

  test('reject() marks the nearest icon until the given time', () => {
    const d = new CameraDwell();
    const now = feed(d, 0, 2, () => [{ x: 150, y: 140 }, { x: 20, y: 20 }], () => BOX);
    d.reject({ x: 152, y: 141 }, 24, now + 1_000);
    expect(d.readings(now).map(x => x.rejected)).toEqual([true, false]);
    expect(d.readings(now + 1_000).map(x => x.rejected)).toEqual([false, false]);
  });

  test('keeps an icon\'s history through a few seconds undetected, not longer', () => {
    // Missing for 4s (merged with an enemy in a fight) and turning up a little
    // further on: the same icon, history intact.
    const d = new CameraDwell();
    let now = feed(d, 0, 20, () => [{ x: 150, y: 140 }], () => BOX);
    now = feed(d, now, 4, () => [], () => BOX);
    now = feed(d, now, 1, () => [{ x: 170, y: 140 }], () => BOX);
    expect(d.readings()).toHaveLength(1);
    expect(d.readings()[0].readableMs).toBeGreaterThan(15_000);
    // Gone for 6s: forgotten.
    now = feed(d, now, 6, () => [], () => BOX);
    feed(d, now, 1, () => [{ x: 170, y: 140 }], () => BOX);
    expect(d.readings()[0].readableMs).toBeLessThanOrEqual(1_000);
  });
});

describe('cameraFavourite and cameraSwitchTarget', () => {
  const r = (dwell: number, readableMs = 20_000, x = 0, rejected = false) =>
    ({ x, y: 0, dwell, readableMs, seenMs: readableMs, rejected });

  test('an icon seen mostly with the rectangle unreadable does not count', () => {
    // A laner in the map's corner, where the camera on them reads as nothing:
    // only their glances elsewhere were counted.
    const cornered = { ...r(0.0, 12_000, 1), seenMs: 30_000 };
    const watched = r(0.7, 20_000, 2);
    expect(12_000 / 30_000).toBeLessThan(CAMERA_DWELL_MIN_READABLE_SHARE);
    expect(cameraSwitchTarget([cornered, watched], cornered)).toBeNull();
    expect(cameraFavourite([{ ...r(0.9, 12_000), seenMs: 30_000 }, r(0)])).toBeNull();
    // Readable enough of the time, it counts.
    const fine = { ...r(0.0, 16_000, 1), seenMs: 30_000 };
    expect(cameraSwitchTarget([fine, watched], fine)).toBe(watched);
  });

  test('an icon the user reset away from is never the camera pick', () => {
    expect(cameraFavourite([r(0.8, 20_000, 0, true), r(0.1)])).toBeNull();
    const followed = r(0.1, 20_000, 1);
    expect(cameraSwitchTarget([followed, r(0.8, 20_000, 2, true)], followed)).toBeNull();
  });

  test('a favourite needs a clear lead, and enough readable time', () => {
    expect(cameraFavourite([r(0.8), r(0.1), r(0.0)])).toEqual(r(0.8));
    expect(cameraFavourite([r(0.8), r(0.3)])).toBeNull(); // the other is watched too
    expect(cameraFavourite([r(0.8), r(0.7)])).toBeNull(); // two together
    expect(cameraFavourite([r(0.8, CAMERA_DWELL_MIN_READABLE_MS - 1), r(0)])).toBeNull();
  });

  test('a switch needs the followed icon unwatched and exactly one other watched', () => {
    const followed = r(0.1, 20_000, 1);
    const target = r(0.7, 20_000, 2);
    expect(cameraSwitchTarget([followed, target, r(0.0)], followed)).toBe(target);
    // A duo lane elsewhere: two others watched, no telling which.
    expect(cameraSwitchTarget([followed, target, r(0.9)], followed)).toBeNull();
    // The followed icon is watched: nothing to correct.
    const watched = r(CAMERA_DWELL_LOW + 0.01);
    expect(cameraSwitchTarget([watched, target], watched)).toBeNull();
    // Not enough history on the followed icon.
    const fresh = r(0, CAMERA_DWELL_MIN_READABLE_MS - 1);
    expect(cameraSwitchTarget([fresh, target], fresh)).toBeNull();
    expect(cameraSwitchTarget([target], null)).toBeNull();
  });

  test('readingNear returns an element of the list it was given', () => {
    const list = [r(0.1, 20_000, 0), r(0.7, 20_000, 50)];
    expect(readingNear(list, { x: 48, y: 0 }, 10)).toBe(list[1]);
    expect(readingNear(list, { x: 25, y: 0 }, 10)).toBeNull();
  });
});

// ---------- Icons whose art is teal ----------

/** A W x W mask and a Blob over everything set in it, as findBlobs makes them. */
function maskOf(W: number, paint: (x: number, y: number) => boolean): { mask: Uint8Array; blob: Blob } {
  const mask = new Uint8Array(W * W);
  let minX = W, maxX = -1, minY = W, maxY = -1, n = 0, sx = 0, sy = 0;
  for (let y = 0; y < W; y++) {
    for (let x = 0; x < W; x++) {
      if (!paint(x, y)) continue;
      mask[y * W + x] = 1;
      n++; sx += x; sy += y;
      minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
  }
  return {
    mask,
    blob: {
      color: 'teal', pixels: n, cx: Math.round(sx / n), cy: Math.round(sy / n), minX, maxX, minY, maxY,
      fillRatio: n / ((maxX - minX + 1) * (maxY - minY + 1)),
    },
  };
}

describe('filledIconRing — an icon whose own art is teal', () => {
  const W = 60;
  const C = 30;
  const R = 13.5; // a 28px icon, the expected diameter 26
  const ringAt = (x: number, y: number) => { const d = Math.hypot(x - C, y - C); return d <= R && d > R - 2.5; };
  // Hair framing the face: the upper part, clear of the centre.
  const hair = (x: number, y: number) => { const d = Math.hypot(x - C, y - C); return d <= R && d > R * 0.5 && y - C <= R * 0.5; };

  test('Gwen: ring and hair in one blob, too filled for a bare ring, is an icon — centred on its ring', () => {
    const { mask, blob } = maskOf(W, (x, y) => ringAt(x, y) || hair(x, y));
    expect(blob.fillRatio).toBeGreaterThan(0.4);
    // The pixel centroid is pulled up into the hair; the ring's centre is not.
    expect(blob.cy).toBeLessThan(C);
    expect(filledIconRing(blob, mask, W, W)).toEqual({ cx: C, cy: C });
  });

  test('Gwen with a minion against her ring is still an icon, centred on the ring (v0.5.21 review)', () => {
    // The dot widens the box by a few pixels, which put the box centre — and
    // every measure taken from it — off the ring.
    const dot = (x: number, y: number) => Math.hypot(x - (C + R + 2), y - (C + 3)) <= 2.5;
    const { mask, blob } = maskOf(W, (x, y) => ringAt(x, y) || hair(x, y) || dot(x, y));
    expect(blob.maxX - blob.minX + 1).toBeGreaterThan(2 * R + 3);
    const at = filledIconRing(blob, mask, W, W)!;
    expect(at).not.toBeNull();
    expect(Math.hypot(at.cx - C, at.cy - C)).toBeLessThanOrEqual(1);
  });

  test('...and with a minion wave against it, the wave is left out of the fit', async () => {
    const wave = [[C + R + 2, C + 3], [C + R + 3, C - 3], [C + R + 1, C + 8], [C + R + 4, C + 1]];
    const { mask, blob } = maskOf(W, (x, y) =>
      ringAt(x, y) || hair(x, y) || wave.some(([dx, dy]) => Math.hypot(x - dx, y - dy) <= 2.5));
    const at = filledIconRing(blob, mask, W, W)!;
    expect(at).not.toBeNull();
    expect(Math.hypot(at.cx - C, at.cy - C)).toBeLessThanOrEqual(1);
  });

  test('a shallow arc, whose circle is centred far off it: not an icon', () => {
    const { mask, blob } = maskOf(W, (x, y) => {
      const d = Math.hypot(x - C, y - (C + 40));
      return d <= 52 && d > 46 && Math.abs(x - C) <= 13;
    });
    expect(filledIconRing(blob, mask, W, W)).toBeNull();
  });

  test('a solid disc is round and ringed too, but teal right through: not an icon', () => {
    const { mask, blob } = maskOf(W, (x, y) => Math.hypot(x - C, y - C) <= R);
    expect(discShare(mask, W, W, C, C, R * 0.6, 1)).toBe(1);
    expect(filledIconRing(blob, mask, W, W)).toBeNull();
  });

  test('a turret and the minions round it: not round, not an icon', () => {
    // A shield-shaped marker with dots scattered round it, some touching.
    const dots = [[C - 12, C - 2], [C + 11, C + 3], [C - 5, C + 11], [C + 4, C - 12], [C + 9, C - 8]];
    const { mask, blob } = maskOf(W, (x, y) =>
      (Math.abs(x - C) <= 8 && y >= C - 9 && y <= C + 7 - Math.abs(x - C) / 2) ||
      dots.some(([dx, dy]) => Math.hypot(x - dx, y - dy) <= 2.5) ||
      (Math.abs(y - C) <= 1 && Math.abs(x - C) <= 12));
    expect(blob.fillRatio).toBeGreaterThan(0.4);
    expect(filledIconRing(blob, mask, W, W)).toBeNull();
  });

  test('an oval band, hollow in the middle, is not round: not an icon', () => {
    // The shape of the 2026-10-08 turret ringed by its minions: filled past
    // 0.4 and clear in the centre, like an icon — only its outline is not a
    // circle.
    const { mask, blob } = maskOf(W, (x, y) => {
      const e = Math.hypot((x - C) / 13, (y - C) / 8);
      return e <= 1 && e > 0.55;
    });
    expect(blob.fillRatio).toBeGreaterThan(0.4);
    expect(discShare(mask, W, W, C, C, ((blob.maxX - blob.minX + blob.maxY - blob.minY + 2) / 4) * 0.6, 1)).toBeLessThanOrEqual(0.6);
    expect(filledIconRing(blob, mask, W, W)).toBeNull();
  });

  test('two icons merged into one blob stay rejected, as before', () => {
    const { mask, blob } = maskOf(W, (x, y) =>
      (ringAt(x + 8, y) || hair(x + 8, y)) || (ringAt(x - 8, y) || hair(x - 8, y)));
    expect(filledIconRing(blob, mask, W, W)).toBeNull();
  });

  test('the measures themselves', () => {
    const { mask } = maskOf(W, ringAt);
    expect(outlineRoundness(mask, W, W, C, C, R + 3, 1)).toBe(1);
    expect(discShare(mask, W, W, C, C, R * 0.6, 1)).toBe(0);
    // Half a ring: round only where it is.
    const half = maskOf(W, (x, y) => ringAt(x, y) && x >= C).mask;
    expect(outlineRoundness(half, W, W, C, C, R + 3, 1)).toBeCloseTo(0.5, 1);
  });
});

describe('TeammateVerdicts', () => {
  const D = 24;
  const MATE = { x: 100, y: 100 };

  test('two teammate verdicts in a row set an icon aside; one is enough only when asked', () => {
    const v = new TeammateVerdicts();
    v.update([MATE], ['teammate'], 0, D);
    expect(v.isTeammate(MATE.x, MATE.y, 0, D)).toBe(false);
    expect(v.isTeammate(MATE.x, MATE.y, 0, D, 1)).toBe(true);
    v.update([{ x: 102, y: 101 }], ['teammate'], 500, D); // it moved a little
    expect(v.isTeammate(103, 101, 500, D)).toBe(true);
    // Somewhere else entirely is not it.
    expect(v.isTeammate(160, 100, 500, D)).toBe(false);
  });

  test('a verdict of "you" clears it at once; an unsure run keeps it, without adding', () => {
    const v = new TeammateVerdicts();
    v.update([MATE], ['teammate'], 0, D);
    v.update([MATE], [null], 500, D);
    expect(v.isTeammate(MATE.x, MATE.y, 500, D)).toBe(false);
    v.update([MATE], ['teammate'], 1000, D);
    expect(v.isTeammate(MATE.x, MATE.y, 1000, D)).toBe(true);
    v.update([MATE], [null], 1500, D);
    expect(v.isTeammate(MATE.x, MATE.y, 1500, D)).toBe(true);
    v.update([MATE], ['self'], 2000, D);
    expect(v.isTeammate(MATE.x, MATE.y, 2000, D, 1)).toBe(false);
  });

  test('goes stale without fresh verdicts, and forgets icons no longer scored', () => {
    const v = new TeammateVerdicts();
    v.update([MATE], ['teammate'], 0, D);
    v.update([MATE], ['teammate'], 500, D);
    expect(v.isTeammate(MATE.x, MATE.y, 2500, D)).toBe(true);
    expect(v.isTeammate(MATE.x, MATE.y, 2501, D)).toBe(false);
    v.update([{ x: 20, y: 20 }], [null], 600, D);
    expect(v.isTeammate(MATE.x, MATE.y, 600, D, 1)).toBe(false);
  });
});
