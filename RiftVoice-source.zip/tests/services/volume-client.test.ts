import { VolumeClient } from '../../src/services/volume-client';

// volume-client is pure transport; stub fetch and assert what we put on the wire.
// The #22 ally-proximity flag is the contract that matters here: a field-name typo
// would silently no-op against the server (which just wouldn't see the flag), so
// the server's own tests can't catch it — this one does.
const fetchMock = jest.fn();
(globalThis as any).fetch = fetchMock;

describe('VolumeClient.computeVolumes', () => {
  beforeEach(() => {
    fetchMock.mockReset();
    fetchMock.mockResolvedValue({
      ok: true,
      json: async () => ({ peerVolumes: {} }),
    });
  });

  test('sends the allyProximity flag (and identity/position) in the request body', async () => {
    const client = new VolumeClient();
    await client.computeVolumes({ x: 1, y: 2 }, 'room-1', 'Me', true);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const body = JSON.parse(fetchMock.mock.calls[0][1].body);
    expect(body).toMatchObject({
      myPosition: { x: 1, y: 2 },
      roomId: 'room-1',
      name: 'Me',
      allyProximity: true,
    });
  });

  test('passes allyProximity=false through (global/full ally volume)', async () => {
    const client = new VolumeClient();
    await client.computeVolumes({ x: 0, y: 0 }, 'room-2', 'Me', false);

    const body = JSON.parse(fetchMock.mock.calls[0][1].body);
    expect(body.allyProximity).toBe(false);
  });

  test('asks for allies only when told to, and otherwise leaves the field off', async () => {
    const client = new VolumeClient();
    await client.computeVolumes({ x: 0, y: 0 }, 'room-3', 'Me', true, true);
    await client.computeVolumes({ x: 0, y: 0 }, 'room-3', 'Me', true);
    expect(JSON.parse(fetchMock.mock.calls[0][1].body).alliesOnly).toBe(true);
    expect('alliesOnly' in JSON.parse(fetchMock.mock.calls[1][1].body)).toBe(false);
  });
});

test('strict mode rejects a legacy server instead of accepting unrestricted volumes', async () => {
  fetchMock.mockResolvedValue({ ok: true, json: async () => ({ peerVolumes: { farAlly: 1 } }) });
  await expect(new VolumeClient().computeVolumes({ x: 1, y: 2 }, 'r', 'me', true, false, true)).rejects.toThrow('Update the voice server');
  fetchMock.mockResolvedValue({ ok: true, json: async () => ({ strictProximity: true, peerVolumes: { nearAlly: 1 } }) });
  await expect(new VolumeClient().computeVolumes({ x: 1, y: 2 }, 'r', 'me', true, false, true)).resolves.toMatchObject({ peerVolumes: { nearAlly: 1 } });
  expect(JSON.parse(fetchMock.mock.calls[fetchMock.mock.calls.length - 1][1].body).strictProximity).toBe(true);
});

