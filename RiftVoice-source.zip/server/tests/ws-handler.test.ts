import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { EventEmitter } from 'node:events';
import type { WebSocket } from 'ws';
import { RoomManager } from '../src/rooms.js';
import { handleConnection, TAKEOVER_CLOSE_CODE, SHARED_RESET_ROOM_MS, SHARED_RESET_SENDER_MS } from '../src/ws-handler.js';
import { Heartbeat, type LivenessTracker, type PingableSocket } from '../src/heartbeat.js';
import type { ServerMessage } from '../src/types.js';

/**
 * Stand-in for a `ws` socket: enough of the surface that handleConnection uses,
 * plus recorders for everything it does to the socket. Driving the real handler
 * (rather than a mock of it) is the point — these tests assert on the routing
 * decisions the handler actually makes.
 */
class FakeSocket extends EventEmitter {
  readyState = 1;
  readonly OPEN = 1;
  readonly sent: ServerMessage[] = [];
  readonly closes: Array<{ code?: number; reason?: string }> = [];
  terminations = 0;
  pings = 0;

  send(raw: string): void {
    this.sent.push(JSON.parse(raw) as ServerMessage);
  }

  close(code?: number, reason?: string): void {
    this.closes.push({ code, reason });
    this.readyState = 3;
  }

  terminate(): void {
    this.terminations += 1;
    this.readyState = 3;
  }

  ping(): void {
    this.pings += 1;
  }

  /** Feed an inbound client message, the way the ws library would. */
  deliver(msg: unknown): void {
    this.deliverRaw(JSON.stringify(msg));
  }

  /**
   * Feed bytes that never went through JSON.stringify. `emit` is synchronous,
   * so a handler that throws throws out of here — which is exactly what it does
   * to the process in production, where nothing sits between the receiver and
   * the listener.
   */
  deliverRaw(raw: string): void {
    this.emit('message', Buffer.from(raw));
  }

  received(type: ServerMessage['type']): ServerMessage[] {
    return this.sent.filter(m => m.type === type);
  }

  get ws(): WebSocket {
    return this as unknown as WebSocket;
  }
}

class SpyHeartbeat implements LivenessTracker {
  readonly marked: PingableSocket[] = [];
  markAlive(ws: PingableSocket): void {
    this.marked.push(ws);
  }
}

describe('handleConnection', () => {
  let rooms: RoomManager;
  let heartbeat: Heartbeat;

  function connect(): FakeSocket {
    const sock = new FakeSocket();
    handleConnection(sock.ws, rooms, heartbeat);
    return sock;
  }

  beforeEach(() => {
    rooms = new RoomManager();
    heartbeat = new Heartbeat();
    // The eviction path arms a real timer; fake timers keep it out of the
    // other tests and let the eviction test assert on it directly.
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('duplicate-name takeover', () => {
    it('routes signaling to the newest connection under a name', () => {
      // The reported bug: with two entries under "Bob", findInRoom resolves the
      // first (stale) one and every offer/answer/ICE candidate is dropped
      // silently. Reverting the eviction inverts both assertions below.
      const alice = connect();
      const bob1 = connect();
      const bob2 = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob1.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      bob2.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      alice.deliver({ type: 'signal', to: 'Bob', payload: { sdp: 'offer' } });

      expect(bob2.received('signal')).toHaveLength(1);
      expect(bob2.received('signal')[0].from).toBe('Alice');
      expect(bob1.received('signal')).toHaveLength(0);
    });

    it('does not announce a departure when the superseded socket closes', () => {
      // peer_left is keyed by NAME. Broadcasting one for the evicted socket
      // makes every peer tear down the connection to the LIVE socket of that
      // same name — the second, more damaging half of the bug.
      const alice = connect();
      const bob1 = connect();
      const bob2 = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob1.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      bob2.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      bob1.emit('close');

      expect(alice.received('peer_left')).toHaveLength(0);
      expect(rooms.findInRoom('r1', 'Bob')!.ws).toBe(bob2.ws);
    });

    it('closes the evicted socket with the takeover code, then terminates it', () => {
      // close() alone would sit in CLOSING for ws's 30 s close timeout on the
      // half-open socket eviction exists for, holding a per-IP connection slot.
      const bob1 = connect();
      const bob2 = connect();
      bob1.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      bob2.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      expect(bob1.closes).toHaveLength(1);
      expect(bob1.closes[0].code).toBe(TAKEOVER_CLOSE_CODE);
      expect(bob1.terminations).toBe(0);

      vi.advanceTimersByTime(1000);
      expect(bob1.terminations).toBe(1);
    });

    it('leaves the other peers in the room untouched', () => {
      const alice = connect();
      const bob1 = connect();
      const bob2 = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob1.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      bob2.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      expect(alice.closes).toHaveLength(0);
      expect(rooms.getPeers('r1')).toEqual(['Alice', 'Bob']);
      // The joiner's room_state must not list itself.
      expect(bob2.received('room_state')[0].peers).toEqual(['Alice']);
    });
  });

  describe('re-join', () => {
    it('notifies the old room when a client moves to a different room', () => {
      // This branch was dead: it called leave() and then getOthersInRoom(),
      // which returns [] once the ws has no entry, so nobody was ever told.
      const alice = connect();
      const bob = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      bob.deliver({ type: 'join', room: 'r2', name: 'Bob' });

      expect(alice.received('peer_left').map(m => m.name)).toEqual(['Bob']);
      expect(rooms.getPeers('r1')).toEqual(['Alice']);
      expect(rooms.getPeers('r2')).toEqual(['Bob']);
    });

    it('treats a repeat join on the same socket as idempotent', () => {
      // If this path fell through to rooms.join(), the dedup would find this
      // socket's OWN entry and the handler would close the live connection.
      const alice = connect();
      const bob = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      const aliceBefore = alice.sent.length;

      bob.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      expect(bob.closes).toHaveLength(0);
      expect(bob.terminations).toBe(0);
      expect(alice.sent).toHaveLength(aliceBefore); // no peer_left, no peer_joined
      // A fresh room_state, built from the OTHER clients — never including self.
      expect(bob.received('room_state')).toHaveLength(2);
      expect(bob.received('room_state')[1].peers).toEqual(['Alice']);

      // ...and the socket is still the one signaling resolves to.
      alice.deliver({ type: 'signal', to: 'Bob', payload: { sdp: 'offer' } });
      expect(bob.received('signal')).toHaveLength(1);
    });

    it('refreshes team on a repeat join', () => {
      const bob = connect();
      bob.deliver({ type: 'join', room: 'r1', name: 'Bob', team: 'ORDER' });
      bob.deliver({ type: 'join', room: 'r1', name: 'Bob', team: 'CHAOS' });
      expect(rooms.getClientInfo(bob.ws)?.team).toBe('CHAOS');
    });
  });

  describe('close', () => {
    it('announces a real departure exactly once', () => {
      const alice = connect();
      const bob = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      bob.emit('close');

      expect(alice.received('peer_left').map(m => m.name)).toEqual(['Bob']);
      expect(rooms.getPeers('r1')).toEqual(['Alice']);
    });

    it('says nothing for a socket that never joined', () => {
      const alice = connect();
      const stranger = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });

      stranger.emit('close');
      expect(alice.received('peer_left')).toHaveLength(0);
    });
  });

  describe('join validation', () => {
    const bad: Array<[string, unknown]> = [
      ['a name past the length cap', { type: 'join', room: 'r1', name: 'a'.repeat(65) }],
      ['a control character in the name', { type: 'join', room: 'r1', name: 'Ali\x00ce' }],
      ['a non-string name', { type: 'join', room: 'r1', name: {} }],
      ['a non-string room', { type: 'join', room: 123, name: 'Alice' }],
      ['a room id outside the charset', { type: 'join', room: 'r 1', name: 'Alice' }],
      ['a missing name', { type: 'join', room: 'r1' }],
    ];

    for (const [label, msg] of bad) {
      it(`rejects ${label} without joining`, () => {
        const sock = connect();
        sock.deliver(msg);

        expect(sock.received('error')).toHaveLength(1);
        expect(sock.received('room_state')).toHaveLength(0);
        expect(rooms.getPeers('r1')).toEqual([]);
        // The socket stays open: a retry with the same values cannot succeed,
        // and closing would spin the client's reconnect loop forever.
        expect(sock.closes).toHaveLength(0);
      });
    }
  });

  describe('liveness', () => {
    it('marks the connection alive on every inbound message', () => {
      // The 10 Hz coords stream is what makes reaping a playing client
      // impossible; without this call site nothing but a pong keeps a client
      // alive, and nothing else in the suite covers it.
      const spy = new SpyHeartbeat();
      const sock = new FakeSocket();
      handleConnection(sock.ws, rooms, spy);

      sock.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      sock.deliver({ type: 'coords', x: 1, y: 2 });

      expect(spy.marked).toHaveLength(2);
      expect(spy.marked[0]).toBe(sock.ws);
    });

    it('marks a rate-limited message alive too', () => {
      // A throttled client is still a live one; reaping it would tear down
      // working audio for every peer in its room.
      const spy = new SpyHeartbeat();
      const sock = new FakeSocket();
      handleConnection(sock.ws, rooms, spy);
      sock.deliver({ type: 'join', room: 'r1', name: 'Alice' });

      // Past the 200-message bucket capacity, with the clock frozen so it
      // cannot refill — the tail of these is throttled.
      for (let i = 0; i < 400; i++) sock.deliver({ type: 'coords', x: 1, y: 2 });

      expect(sock.received('error').length).toBeGreaterThan(0);
      expect(spy.marked).toHaveLength(401);
    });
  });

  describe('signal relay', () => {
    it('tells the sender when the target is not in the room', () => {
      const alice = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      alice.deliver({ type: 'signal', to: 'Nobody', payload: {} });

      expect(alice.received('error')).toHaveLength(1);
    });

    it('tells the sender when the target socket is no longer open', () => {
      // Previously a silent drop — exactly the invisible failure this cluster
      // exists to remove.
      const alice = connect();
      const bob = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });
      bob.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      bob.readyState = 3; // socket died without a close event yet

      alice.deliver({ type: 'signal', to: 'Bob', payload: {} });
      expect(alice.received('error')).toHaveLength(1);
    });
  });

  describe('malformed frames', () => {
    // Every case here is reachable by a stranger with no auth and no join.
    // `'null'` is four bytes and used to take the process down: JSON.parse
    // returns null, and reading `.type` off it throws out of the synchronous
    // 'message' emit with nothing above to catch it.
    const nonObjects: Array<[string, string]> = [
      ['null', 'null'],
      ['a bare number', '1'],
      ['a bare string', '"x"'],
      ['an array', '[1,2]'],
      ['a bare boolean', 'false'],
    ];

    for (const [label, raw] of nonObjects) {
      it(`answers ${label} with an error instead of throwing`, () => {
        const sock = connect();

        expect(() => sock.deliverRaw(raw)).not.toThrow();

        // The exact text matters: the catch-all below the switch would also
        // produce *an* error frame after a crash, which is what made a weaker
        // assertion here pass with the guard deleted.
        expect(sock.received('error')).toHaveLength(1);
        expect(sock.received('error')[0].message).toBe('Invalid message');
        expect(sock.closes).toHaveLength(0);
      });
    }

    it('answers unparseable bytes with an error instead of throwing', () => {
      const sock = connect();

      expect(() => sock.deliverRaw('{')).not.toThrow();

      expect(sock.received('error')[0].message).toBe('Invalid JSON');
    });

    it('keeps the connection usable after a malformed frame', () => {
      // The crash cost every room on the process; the floor for the fix is that
      // the sender's own session survives its own bad frame.
      const alice = connect();
      const sock = connect();
      alice.deliver({ type: 'join', room: 'r1', name: 'Alice' });

      sock.deliverRaw('null');
      sock.deliver({ type: 'join', room: 'r1', name: 'Bob' });

      expect(sock.received('room_state')[0].peers).toEqual(['Alice']);
      expect(alice.received('peer_joined').map(m => m.name)).toEqual(['Bob']);
    });

    it('does not let a throw deeper in the handler escape the listener', () => {
      // Defence in depth for the switch arms: any future throw inside one has
      // the same blast radius as the null deref did.
      const sock = connect();
      const boom = new Error('kaboom');
      vi.spyOn(rooms, 'getClientInfo').mockImplementationOnce(() => {
        throw boom;
      });

      expect(() => sock.deliver({ type: 'coords', x: 1, y: 2 })).not.toThrow();
    });
  });

  describe('shared RESET (opt-in)', () => {
    function lobby(optIns: Record<string, boolean | undefined>): Record<string, FakeSocket> {
      const out: Record<string, FakeSocket> = {};
      for (const [name, sharedReset] of Object.entries(optIns)) {
        out[name] = connect();
        out[name].deliver({ type: 'join', room: 'r1', name, ...(sharedReset === undefined ? {} : { sharedReset }) });
      }
      return out;
    }

    it('relays a reset only to the others who opted in, with the sender\'s name and nothing else', () => {
      const p = lobby({ Alice: true, Bob: true, Carol: false, Dave: undefined, Erin: true });
      p.Alice.deliver({ type: 'reset_all', payload: { evil: 1 }, x: 5 });
      expect(p.Bob.received('reset')).toEqual([{ type: 'reset', from: 'Alice' }]);
      expect(p.Erin.received('reset')).toEqual([{ type: 'reset', from: 'Alice' }]);
      // Not opted in (off, or a client too old to know the setting): nothing.
      expect(p.Carol.received('reset')).toHaveLength(0);
      expect(p.Dave.received('reset')).toHaveLength(0);
      // Never echoed back.
      expect(p.Alice.received('reset')).toHaveLength(0);
    });

    it('ignores a reset from a client that has not opted in itself', () => {
      const p = lobby({ Alice: false, Bob: true });
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(0);
    });

    it('follows the setting when it is flipped mid-game, either way', () => {
      const p = lobby({ Alice: true, Bob: false });
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(0);
      p.Bob.deliver({ type: 'shared_reset', on: true });
      vi.advanceTimersByTime(SHARED_RESET_SENDER_MS);
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
      p.Bob.deliver({ type: 'shared_reset', on: 'yes' }); // not literally true: off
      vi.advanceTimersByTime(SHARED_RESET_SENDER_MS);
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
    });

    it('does not carry an opt-in over to a connection that takes over the name', () => {
      const p = lobby({ Alice: true, Bob: true });
      const bob2 = connect();
      bob2.deliver({ type: 'join', room: 'r1', name: 'Bob' });
      p.Alice.deliver({ type: 'reset_all' });
      expect(bob2.received('reset')).toHaveLength(0);
    });

    it('is rate limited per room and per sender', () => {
      const p = lobby({ Alice: true, Bob: true, Carol: true });
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
      // Anyone else in the same room, too soon: dropped.
      vi.advanceTimersByTime(SHARED_RESET_ROOM_MS - 1);
      p.Carol.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
      // Past the room's cooldown, Carol may; Alice, within her own, may not.
      vi.advanceTimersByTime(1);
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
      p.Carol.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toEqual([{ type: 'reset', from: 'Alice' }, { type: 'reset', from: 'Carol' }]);
      // Sender cooldown longer than the room's: Alice again only after hers.
      vi.advanceTimersByTime(SHARED_RESET_SENDER_MS - SHARED_RESET_ROOM_MS);
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(3);
    });

    it('keeps the per-sender limit across a reconnect under the same name', () => {
      const p = lobby({ Alice: true, Bob: true });
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
      vi.advanceTimersByTime(SHARED_RESET_ROOM_MS);
      const alice2 = connect();
      alice2.deliver({ type: 'join', room: 'r1', name: 'Alice', sharedReset: true });
      alice2.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(1);
      vi.advanceTimersByTime(SHARED_RESET_SENDER_MS - SHARED_RESET_ROOM_MS);
      alice2.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(2);
    });

    it('takes the opt-in from a repeated join on the same connection', () => {
      const p = lobby({ Alice: true, Bob: true });
      p.Bob.deliver({ type: 'join', room: 'r1', name: 'Bob', sharedReset: false });
      p.Alice.deliver({ type: 'reset_all' });
      expect(p.Bob.received('reset')).toHaveLength(0);
    });

    it('keeps rooms apart', () => {
      const p = lobby({ Alice: true });
      const other = connect();
      other.deliver({ type: 'join', room: 'r2', name: 'Zed', sharedReset: true });
      p.Alice.deliver({ type: 'reset_all' });
      expect(other.received('reset')).toHaveLength(0);
    });

    it('needs a room', () => {
      const sock = connect();
      sock.deliver({ type: 'reset_all' });
      sock.deliver({ type: 'shared_reset', on: true });
      expect(sock.received('error')).toHaveLength(2);
    });
  });
});
