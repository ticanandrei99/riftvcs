use serde::Serialize;
const LATEST: &str = "https://api.github.com/repos/ticanandrei99/riftvcs/releases/latest";
const PAGE: &str = "https://github.com/ticanandrei99/riftvcs/releases";
#[derive(Serialize, Clone)]
pub struct UpdateInfo {
    pub current_version: String, pub latest_version: String,
    pub update_available: bool, pub channel_ready: bool,
    pub download_url: Option<String>, pub notes: Option<String>,
}
fn version(value: &str) -> Option<[u32;3]> {
    let values = value.strip_prefix('v').unwrap_or(value).split('.').map(str::parse::<u32>).collect::<Result<Vec<_>,_>>().ok()?;
    values.try_into().ok()
}
fn release_info(json: &serde_json::Value, current: &str) -> Result<UpdateInfo,String> {
    let tag = json["tag_name"].as_str().ok_or("Invalid release tag")?;
    let latest = version(tag).ok_or("Release must use vMAJOR.MINOR.PATCH")?;
    let installed = version(current).ok_or("Invalid installed version")?;
    let ready = json["assets"].as_array().map(|assets| assets.iter().any(|asset| {
        let name = asset["name"].as_str().unwrap_or("");
        let url = asset["browser_download_url"].as_str().unwrap_or("");
        name.starts_with("RiftVoice") && name.ends_with("-setup.exe") &&
            url.starts_with("https://github.com/ticanandrei99/riftvcs/releases/download/")
    })).unwrap_or(false);
    Ok(UpdateInfo {current_version:current.into(), latest_version:tag.trim_start_matches('v').into(),
        update_available:latest>installed && ready, channel_ready:ready,
        download_url:None, notes:None})
}
#[tauri::command]
pub async fn check_for_update() -> Result<UpdateInfo,String> {
    let current = env!("CARGO_PKG_VERSION");
    let client = reqwest::Client::builder().timeout(std::time::Duration::from_secs(15)).build().map_err(|_|"Update check unavailable")?;
    let response = client.get(LATEST).header("User-Agent","RiftVoice-updater").header("Accept","application/vnd.github+json").send().await.map_err(|_|"Update check unavailable")?;
    if response.status() == reqwest::StatusCode::NOT_FOUND {
        return Ok(UpdateInfo {current_version:current.into(),latest_version:current.into(),update_available:false,channel_ready:false,download_url:None,notes:None});
    }
    if !response.status().is_success() { return Err("Update check unavailable; try again later".into()); }
    let json = response.json().await.map_err(|_|"Invalid release response")?;
    release_info(&json,current)
}
// Updates use the official installer, with the player's consent. Never execute
// arbitrary URLs supplied by the frontend or replace this fork with upstream.
#[tauri::command]
pub async fn download_and_apply_update(_url: String) -> Result<(),String> {
    Err("Use the official RiftVoice release installer".into())
}
#[tauri::command]
pub fn open_release_page() -> Result<(),String> {
    std::process::Command::new("explorer.exe").arg(PAGE).spawn().map_err(|_|"Cannot open releases page")?;
    Ok(())
}
pub fn handle_complete_update_arg() {}
#[cfg(test)]
mod tests {
    use super::*;
    fn release(tag: &str, url: &str) -> serde_json::Value { serde_json::json!({"tag_name":tag,"assets":[{"name":"RiftVoice_0.2.0_x64-setup.exe","browser_download_url":url}]}) }
    #[test] fn newer_release_requires_own_installer() {
        let url="https://github.com/ticanandrei99/riftvcs/releases/download/v0.2.0/RiftVoice_0.2.0_x64-setup.exe";
        assert!(release_info(&release("v0.2.0",url),"0.1.0").unwrap().update_available);
        assert!(!release_info(&release("v0.2.0",url),"0.2.0").unwrap().update_available);
        assert!(!release_info(&release("v0.2.0",url),"0.3.0").unwrap().update_available);
        assert!(!release_info(&release("v0.2.0","https://evil.test/setup.exe"),"0.1.0").unwrap().channel_ready);
    }
    #[test] fn malformed_versions_rejected() {
        for tag in ["main","v1.2","1.2.3.4","1.2.3-beta","1.a.3"] { assert!(version(tag).is_none()); }
        assert!(release_info(&serde_json::json!({}),"0.1.0").is_err());
    }
}
