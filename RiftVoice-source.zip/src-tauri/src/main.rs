#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod audio_out;
mod capture;
mod game_bundle;
mod game_window;
mod global_keys;
mod key_decision;
mod lcu;
mod mic_permission;
mod updater;

use capture::CaptureState;
use std::fs::File;
use std::io::Write;
use std::sync::Mutex;
use std::time::Duration;
use tauri::Manager;

/// Holds the open log file. Written to only when the frontend's Debug toggle
/// is on (the TS logging layer batches console calls into append_log_lines).
struct LogFile {
    file: Mutex<Option<File>>,
}

/// Single-line write. The frontend batches through append_log_lines; this stays
/// registered so a bundle/binary version skew still produces a log file.
#[tauri::command]
fn append_log(state: tauri::State<LogFile>, line: String) {
    write_log_lines(&state, std::slice::from_ref(&line));
}

/// Batched write: one lock and one flush for a whole batch of console lines.
#[tauri::command]
fn append_log_lines(state: tauri::State<LogFile>, lines: Vec<String>) {
    write_log_lines(&state, &lines);
}

/// Open the directory that holds the rolling debug log in Explorer so the
/// user can grab the file and attach it to a GitHub issue.
#[tauri::command]
fn open_log_folder(app: tauri::AppHandle) -> Result<(), String> {
    let dir = app
        .path()
        .app_local_data_dir()
        .map_err(|e| e.to_string())?;
    let _ = std::fs::create_dir_all(&dir);
    std::process::Command::new("explorer")
        .arg(&dir)
        .spawn()
        .map_err(|e| e.to_string())?;
    Ok(())
}

fn write_log_lines(state: &tauri::State<LogFile>, lines: &[String]) {
    if let Ok(mut guard) = state.file.lock() {
        if let Some(f) = guard.as_mut() {
            for line in lines {
                let _ = writeln!(f, "{}", line);
            }
            game_bundle::tee(lines);
            // One flush per batch — a crash loses at most the batch the
            // frontend had already handed over.
            let _ = f.flush();
        }
    }
}

/// Write a `[rust]`-tagged line to the log file from non-frontend code paths
/// (the global-shortcut handler, setup hooks, etc).
pub(crate) fn rust_log<S: AsRef<str>>(app: &tauri::AppHandle, msg: S) {
    let Some(state) = app.try_state::<LogFile>() else { return };
    let Ok(mut guard) = state.file.lock() else { return };
    let Some(f) = guard.as_mut() else { return };
    // Same ISO-8601 UTC shape core/logging.ts writes, so `[rust]` lines and
    // console lines interleave in file order and read as one timeline.
    let now = chrono::Utc::now();
    let line = format!("{} [rust] {}", now.format("%Y-%m-%dT%H:%M:%S%.3fZ"), msg.as_ref());
    let _ = writeln!(f, "{line}");
    let _ = f.flush();
    drop(guard);
    game_bundle::tee(std::slice::from_ref(&line));
}

// Hit-test box (in window-local px) for which clicks the overlay (panel)
// should actually receive — everything else passes through to the game.
static PANEL_HIT_RECT: Mutex<(i32, i32)> = Mutex::new((240, 400));

/// JS calls this whenever the panel resizes (settings expand, collapse, etc).
#[tauri::command]
fn set_panel_size(width: i32, height: i32) {
    *PANEL_HIT_RECT.lock().unwrap() = (width, height);
}

/// v0.3: dynamic overlay window height. JS measures panel.scrollHeight,
/// multiplies by devicePixelRatio, and calls this so the window fits its
/// content (instead of clipping at the fixed 400px in tauri.conf.json). Also
/// updates PANEL_HIT_RECT height so clicks below the now-shrunk panel pass
/// through to the game (#11).
///
/// `height` is in PHYSICAL pixels (JS already applied the DPR). v0.4.1 fixed a
/// DPI bug here: the old code treated the logical scrollHeight as physical, so
/// a 125/150%-scaled laptop got a too-short window and clipped the debug
/// thumbnail (a 100% display was unaffected). Both the window size and the
/// hit-rect are physical, matching the physical Win32 cursor coords the
/// click-through loop compares against.
#[tauri::command]
fn resize_overlay(app: tauri::AppHandle, height: u32) {
    let Some(window) = app.get_webview_window("overlay") else { return };
    // Generous physical-px safety clamp (the real bound is JS's logical clamp).
    let clamped = height.clamp(100, 4000);
    let current_width = window
        .outer_size()
        .ok()
        .map(|s| s.width)
        .unwrap_or(260);
    let _ = window.set_size(tauri::PhysicalSize::new(current_width, clamped));
    // Mirror the new height into the click-through hit-rect (physical px).
    let mut rect = PANEL_HIT_RECT.lock().unwrap();
    rect.1 = clamped as i32;
}

/// Position the scanner window directly over the minimap region.
/// `x, y, width, height` are physical screen pixels (from the BitBlt capture).
/// Also makes the scanner visible on the first call (it starts hidden).
#[tauri::command]
fn position_scanner(app: tauri::AppHandle, x: f64, y: f64, width: f64, height: f64) {
    let Some(window) = app.get_webview_window("scanner") else { return };
    let _ = window.set_position(tauri::PhysicalPosition::new(x as i32, y as i32));
    let _ = window.set_size(tauri::PhysicalSize::new(width as u32, height as u32));
    make_tool_window(&window);
    let _ = window.show();
}

/// Hide the scanner window. Called when a session ends so the scanner isn't
/// floating mid-screen between games.
#[tauri::command]
fn hide_scanner(app: tauri::AppHandle) {
    if let Some(window) = app.get_webview_window("scanner") {
        let _ = window.hide();
    }
}

/// Marks a helper window (scanner, speaking overlay) as a tool window: OBS's
/// window lists and Alt+Tab leave those out, so a streamer picking lolproxchat.exe
/// in "Application Audio Capture" sees only the panel, "[lolproxchat.exe]: LoLProxChat".
fn make_tool_window(window: &tauri::WebviewWindow) {
    use windows::Win32::Foundation::HWND;
    use windows::Win32::UI::WindowsAndMessaging::{
        GetWindowLongPtrW, SetWindowLongPtrW, GWL_EXSTYLE, WS_EX_APPWINDOW, WS_EX_TOOLWINDOW,
    };
    let Ok(h) = window.hwnd() else { return };
    let hwnd = HWND(h.0 as *mut _);
    unsafe {
        let ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
        let want = (ex | WS_EX_TOOLWINDOW.0 as isize) & !(WS_EX_APPWINDOW.0 as isize);
        if want != ex {
            SetWindowLongPtrW(hwnd, GWL_EXSTYLE, want);
        }
    }
}

/// Put the "who is speaking" window at `x, y` (physical screen pixels: the
/// game's top-left corner, inset) and show it. It is click-through and draws
/// nothing until someone speaks.
#[tauri::command]
fn position_speakers(app: tauri::AppHandle, x: f64, y: f64) {
    let Some(window) = app.get_webview_window("speakers") else { return };
    let _ = window.set_position(tauri::PhysicalPosition::new(x as i32, y as i32));
    let _ = window.set_ignore_cursor_events(true);
    make_tool_window(&window);
    let _ = window.show();
}

/// Hide the speaking overlay when a session ends.
#[tauri::command]
fn hide_speakers(app: tauri::AppHandle) {
    if let Some(window) = app.get_webview_window("speakers") {
        let _ = window.hide();
    }
}

fn main() {
    // Handle the "--complete-update <old-path>" handoff before Tauri starts.
    // If we were launched by an in-flight self-update, this deletes the old
    // .exe and renames us from proxchat.exe.new → proxchat.exe.
    updater::handle_complete_update_arg();

    tauri::Builder::default()
        .manage(CaptureState {
            bounds: Mutex::new(None),
        })
        .manage(LogFile {
            file: Mutex::new(None),
        })
        .setup(|app| {
            // Open the log file once at startup (truncated each session).
            // The TS layer only writes to it while Debug is on.
            if let Ok(dir) = app.path().app_local_data_dir() {
                let _ = std::fs::create_dir_all(&dir);
                // Rotate previous session logs so users who restart the app
                // before grabbing diagnostics don't lose the prior session.
                // Keeps up to 3 sessions: lolproxchat.log (current),
                // lolproxchat.1.log (previous), lolproxchat.2.log (oldest).
                let log_path = dir.join("lolproxchat.log");
                let log_1 = dir.join("lolproxchat.1.log");
                let log_2 = dir.join("lolproxchat.2.log");
                let _ = std::fs::remove_file(&log_2);
                let _ = std::fs::rename(&log_1, &log_2);
                let _ = std::fs::rename(&log_path, &log_1);
                let path = log_path;
                if let Ok(file) = std::fs::OpenOptions::new()
                    .create(true)
                    .write(true)
                    .truncate(true)
                    .open(&path)
                {
                    if let Ok(mut guard) = app.state::<LogFile>().file.lock() {
                        *guard = Some(file);
                    }
                    println!("[proxchat] log file: {}", path.display());
                }
            }

            // First line of every log names the build. Without it a log is not
            // self-identifying, and a bug report against a test build is
            // indistinguishable from one against the release it was meant to
            // fix — which has already cost a round trip with a tester.
            rust_log(
                app.handle(),
                format!(
                    "LoLProxChat {} starting (log: lolproxchat.log is THIS session; \
                     .1.log and .2.log are the two before it)",
                    env!("CARGO_PKG_VERSION"),
                ),
            );

            // Install the low-level WH_KEYBOARD_LL hook for in-game PTT (#1).
            // Replaces the old RegisterHotKey-based plugin which LoL's
            // DirectInput layer was eating. Default PTT = Caps Lock (v0.5.6
            // unbound it, which stranded push-to-talk users; v0.5.7 restored the
            // default — see #27). The overlay pushes any stored user bind on
            // startup. setup_hook logs the install result from the hook thread,
            // where the outcome is actually known.
            global_keys::setup_hook(app.handle().clone());

            // Zip any game a crash or a mid-game quit left unzipped.
            let recover_handle = app.handle().clone();
            let unfinished = game_bundle::unfinished(&recover_handle);
            std::thread::spawn(move || game_bundle::recover(&recover_handle, unfinished));

            for webview in app.webview_windows().values() {
                mic_permission::allow_microphone(webview);
            }

            let Some(window) = app.get_webview_window("overlay") else {
                return Ok(());
            };

            // Scanner is always click-through (never receives input).
            // Neither window carries WDA_EXCLUDEFROMCAPTURE — the HSV-filtered
            // debug image now renders as a thumbnail in the panel instead of
            // being painted into the captured minimap region, so there's no
            // feedback loop to break and ShadowPlay / OBS see everything.
            if let Some(scanner) = app.get_webview_window("scanner") {
                let _ = scanner.set_ignore_cursor_events(true);
                make_tool_window(&scanner);
            }
            // So is the speaking overlay: it sits over the game.
            if let Some(speakers) = app.get_webview_window("speakers") {
                let _ = speakers.set_ignore_cursor_events(true);
                make_tool_window(&speakers);
            }

            // Panel starts globally click-through too. The polling loop below
            // flips it off only when the cursor is over the panel hit-rect.
            let _ = window.set_ignore_cursor_events(true);

            // Stash the HWND as an integer — the windows::HWND type wraps a raw
            // pointer that isn't Send, so we can't hold it across an await.
            let hwnd_addr: isize = match window.hwnd() {
                Ok(h) => h.0 as isize,
                Err(_) => return Ok(()),
            };
            let window_for_loop = window.clone();
            tauri::async_runtime::spawn(async move {
                use windows::Win32::Foundation::{HWND, POINT, RECT};
                use windows::Win32::UI::Input::KeyboardAndMouse::{GetAsyncKeyState, VK_LBUTTON};
                use windows::Win32::UI::WindowsAndMessaging::{GetCursorPos, GetWindowRect};

                let mut last_ignore = true;
                loop {
                    // Skip the hit-test entirely while LMB is held: the user
                    // is mid-drag (or mid-click on a control), and toggling
                    // WS_EX_TRANSPARENT during Windows' native move loop
                    // kills the drag because hit-test returns HTTRANSPARENT
                    // on the next frame before GetWindowRect catches up.
                    let lmb_down = unsafe { (GetAsyncKeyState(VK_LBUTTON.0 as i32) as u16 & 0x8000) != 0 };
                    if lmb_down {
                        tokio::time::sleep(Duration::from_millis(33)).await;
                        continue;
                    }

                    let mut cursor = POINT::default();
                    let mut win_rect = RECT::default();
                    let ok = unsafe {
                        let hwnd = HWND(hwnd_addr as *mut _);
                        GetCursorPos(&mut cursor).is_ok()
                            && GetWindowRect(hwnd, &mut win_rect).is_ok()
                    };

                    if ok {
                        let (pw, ph) = *PANEL_HIT_RECT.lock().unwrap();
                        let over_panel = cursor.x >= win_rect.left
                            && cursor.x < win_rect.left + pw
                            && cursor.y >= win_rect.top
                            && cursor.y < win_rect.top + ph;

                        let should_ignore = !over_panel;
                        if should_ignore != last_ignore {
                            let _ = window_for_loop.set_ignore_cursor_events(should_ignore);
                            last_ignore = should_ignore;
                        }
                    }

                    tokio::time::sleep(Duration::from_millis(33)).await;
                }
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            capture::set_capture_bounds,
            capture::capture_minimap,
            lcu::check_league_running,
            lcu::get_game_state,
            lcu::get_live_client_data,
            lcu::get_live_players,
            lcu::read_league_config_file,
            lcu::get_league_install_dir,
            position_scanner,
            hide_scanner,
            position_speakers,
            hide_speakers,
            audio_out::audio_out_devices,
            audio_out::audio_out_start,
            audio_out::audio_out_push,
            audio_out::audio_out_stop,
            audio_out::audio_out_status,
            game_window::get_game_window_info,
            set_panel_size,
            resize_overlay,
            append_log,
            append_log_lines,
            open_log_folder,
            updater::check_for_update,
            updater::download_and_apply_update,
            updater::open_release_page,
            global_keys::set_ptt_key,
            game_bundle::bundle_start,
            game_bundle::bundle_add_file,
            game_bundle::bundle_finish,
            global_keys::set_ptt_active,
            global_keys::default_ptt_key,
            global_keys::key_name,
            global_keys::set_toggle_key,
        ])
        // Closing the panel ("overlay") window should exit the whole app —
        // otherwise the scanner window (which is decorationless and
        // skip-taskbar) sits invisibly over the minimap with no way to
        // close it. Same applies in reverse: any window-close request
        // tears down the app cleanly.
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { .. } = event {
                window.app_handle().exit(0);
            }
        })
        .run(tauri::generate_context!())
        .expect("error running tauri application");
}
