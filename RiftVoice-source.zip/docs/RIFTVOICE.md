# RiftVoice — versiunea simplificată

## Voce și interfață
Sunt disponibile doar Natural și Robotic, alese manual. Setările vechi Automatic
sau pentru campioni revin la Natural. Vocea nu mai depinde de campion sau skin.
Urmărirea minimapei rămâne necesară exclusiv pentru calcularea proximității.
Meniul este negru cu roșu, în English sau Română, cu X pentru închidere completă.
Modurile de cameră, resetările și diagnosticul sunt disponibile opțional. Implicit se folosește proximitatea din jurul tău. Verificarea actualizărilor se face numai la pornire; vezi UPDATES.ro.md.

Testul local de microfon redă vocea procesată și se oprește după 30 secunde.
Această limită nu se aplică apelului cu ceilalți jucători. Nu se înregistrează vocea.
Oprirea microfonului sau a tuturor vocilor oprește și testul local. Testul rămâne indisponibil cât timp mute este activ și nu repornește automat după reactivare.
Robotic folosește ring modulation bipolară la 70 Hz. Natural este bypass.

## Proximitate strictă
Aliații și inamicii se aud numai în jurul poziției ascultătorului. Volumul este
maxim în raza de 900 unități de joc și scade până la zero la 1350 unități.
Inamicii trebuie să fie și vizibili în observațiile minimapei. Camera nu extinde
raza de ascultare. Nu există voce globală pentru echipă.
Dacă poziția proprie nu este cunoscută, urmărirea este pierdută, harta nu poate
fi urmărită ori cererea de volum eșuează, aplicația oprește redarea tuturor.
Serverul ignoră pozițiile vechi și nu transformă aliații fără poziție în voce globală.
Aceste reguli necesită serverul actualizat cu strictProximity=true în /health.
Clientul refuză răspunsuri de volum fără confirmarea strictProximity=true.

## Server și confidențialitate
Implicit: https://riftvoice-server.onrender.com. Toți utilizatorii aleg aceeași
origine HTTPS și folosesc RiftVoice în același meci.
Conexiunile audio directe sunt blocate: este necesar un releu TURN autentificat.
IP-urile nu sunt afișate în interfață sau în jurnalele ICE ale aplicației.
Operatorul serverului și furnizorul TURN văd inevitabil adresa conexiunii.
Nu este o garanție împotriva unui client modificat sau un sistem de autentificare
anti-cheat. Nu se citește și nu se modifică memoria jocului pentru această funcție.

Pentru ExpressTURN configurează TURN_URLS, TURN_USERNAME și TURN_PASSWORD numai
în Environment pe Render. Nu pune credențiale în repository sau executabil.
Cloudflare Realtime TURN și coturn HMAC rămân suportate pe server.
Vezi docs/RENDER.ro.md pentru pașii de publicare și actualizare.

## Compilare și verificare
Windows x64, Node 22.12+, Rust MSVC din rust-toolchain.toml, Visual Studio C++
Build Tools, Windows SDK și WebView2.

    powershell -ExecutionPolicy Bypass -File scripts/build-windows.ps1

Scriptul rulează verificările și produce executabilul și installerul NSIS.
Pentru proba audio cu noduri Web Audio și WebRTC reale în Edge:

    npm run test:voice-audio

Pentru împachetarea unui build deja verificat:

    powershell -ExecutionPolicy Bypass -File scripts/package-windows.ps1

artifacts/ conține executabil, installer, surse, LICENSE, NOTICE.md și SHA256SUMS.
Verificarea versiunilor se face la pornirea aplicației. O versiune nouă afișează o notificare cu link spre setup; instalarea este pornită de jucător. Vezi UPDATES.ro.md.
Nu folosi updaterul upstream. Binarul rămâne nesemnat.
Păstrează LICENSE și NOTICE.md în distribuție. Proiectul este derivat din
LoLProxChat și folosește licența AGPL-3.0-or-later.

Validarea într-o partidă reală cu două calculatoare, rețele diferite și TURN
rămâne distinctă de testele automate și de verificarea interfeței.
