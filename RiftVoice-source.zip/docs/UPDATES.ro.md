# Actualizări RiftVoice

Aplicația verifică automat doar la pornirea aplicației ultimul release stabil publicat în https://github.com/ticanandrei99/riftvcs/releases. Opțiunea poate fi oprită din meniu. Notificarea apare și când setările sunt închise. Nu întrerupe meciul și nu instalează în tăcere. Butonul deschide pagina oficială; jucătorul descarcă și pornește setup-ul.

Pentru fiecare versiune:
1. Actualizează aceeași versiune numerică în package.json, package-lock.json, src-tauri/Cargo.toml, src-tauri/Cargo.lock și src-tauri/tauri.conf.json.
2. Rulează verificările, build-ul Windows și scripts/package-windows.ps1.
3. Publică un GitHub Release stabil, nu Draft/Pre-release, cu tag vMAJOR.MINOR.PATCH mai mare decât versiunea instalată.
4. Atașează RiftVoice_MAJOR.MINOR.PATCH_x64-setup.exe (fără spații, înlocuiește versiunea), sursa completă RiftVoice-source.zip, licența, NOTICE și sumele SHA256. Numele setup-ului trebuie să înceapă cu RiftVoice și să se termine cu -setup.exe.

Exemplu: pentru utilizatori cu 0.1.0, publică v0.1.1 și RiftVoice_0.1.1_x64-setup.exe. Reîncărcarea unui setup sub același tag 0.1.0 nu produce notificare. Publicarea sursei complete și instrucțiunilor de compilare trebuie păstrată conform licenței incluse. Render actualizează serverul separat; nu distribuie actualizări pentru aplicația Windows.

Nu există încă instalare automată cu semnături criptografice. Nu publica chei private, tokenuri sau date TURN în release.
